SET NAMES 'utf8';

/* ##################################### */
/* 					STRUCTURE				*/
/* ##################################### */

DROP TABLE IF EXISTS PREFIX_product_picture;

/* PHP */
/* PHP:module_reinstall_blockmyaccount(); */;
