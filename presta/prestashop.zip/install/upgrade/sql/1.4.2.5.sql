SET NAMES 'utf8';

/* Fix wrong category level_depth caused by bug in 1.4.0.13 upgrade script */
/* PHP:regenerate_level_depth(); */;