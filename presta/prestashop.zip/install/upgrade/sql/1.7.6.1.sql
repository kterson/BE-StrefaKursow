SET SESSION sql_mode = '';
SET NAMES 'utf8';

/* PHP:ps_1761_update_currencies(); */;
